@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.prozhe


import android.content.Context
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.PixelCopy.Request
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.prozhe.ui.theme.ProzheTheme
import kotlinx.coroutines.launch
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.delay
import java.util.Locale
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Assignment
import java.util.Date

// فعالیت اصلی برنامه
class MainActivity : ComponentActivity() {

    val consultationRequestsList = mutableStateListOf<ConsultationRequests>() // لیست درخواست ها

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProzheTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "welcome_screen") {
                        composable("welcome_screen"){
                            WelcomeScreen(navController = navController)
                        }
                        composable("main_screen") {
                            MainScreen(navController = navController)
                        }
                        composable("kazemi_ferdowsi_screen") {
                            KazemiFerdowsiScreen(navController = navController)
                        }
                        composable("consultation_registration_screen") {
                            ConsultationRegistrationScreen(navController = navController, onAddRequest =
                            {newRequest -> consultationRequestsList.add(newRequest)}
                            )
                        }
                        composable("pending_requests_screen"){
                            PendingRequestsScreen(navController = navController, requests = consultationRequestsList)
                        }
                    }
                }
            }
        }
    }
}

data class ConsultationRequests(
    val name : String,
    val lastName : String,
    val phoneNumber : String,
    val topic : String,
    val submissionTime : Long = System.currentTimeMillis()
)

// فانکشن نمایش Custom Toast
fun showCustomToast(context: Context, message: String) {
    val inflater = LayoutInflater.from(context)
    val layout = inflater.inflate(R.layout.custom_toast_layout, null)

    val textView = layout.findViewById<TextView>(R.id.toast_text)
    textView.text = message

    val toast = Toast(context)
    toast.duration = Toast.LENGTH_LONG


    val yOffsetPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        100f,
        context.resources.displayMetrics
    ).toInt()

    toast.setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, yOffsetPx)

    toast.view = layout
    toast.show()
}

// صفحه خوشامد گویی
@Composable
fun WelcomeScreen(navController: NavController) {

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        visible = true
        delay(3000L)
        visible = false
        delay(500L)
        navController.navigate("main_screen") {
            popUpTo("welcome_screen") { inclusive = true }
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.welcomeee),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically(
                animationSpec = tween(durationMillis = 1000),
                initialOffsetY = { fullHeight -> fullHeight }
            ) + fadeIn(tween(500)),
            exit = slideOutVertically(
                animationSpec = tween( 500),
                targetOffsetY = { fullHeight -> -fullHeight }
            ) + fadeOut(tween(1000))
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "!خوش آمدید",
                    color = Color.White,
                    fontSize = 50.sp,
                    fontWeight = FontWeight.Bold,
                    softWrap = false,
                    maxLines = 1,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// کامپوزبل اصلی صفحه
@Composable
fun MainScreen(navController: NavController) {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.backgroundddd),
            contentDescription = "پس زمینه",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.weight(1f))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp)
                    .padding(bottom = 64.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = { navController.navigate("kazemi_ferdowsi_screen") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A0DAD))
                ) {
                    Text(
                        text = "ورود",
                        color = Color.White,
                        fontSize = 20.sp
                    )
                }

                Button(
                    onClick = { navController.navigate("consultation_registration_screen") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                ) {
                    Text(
                        text = "رزرو وقت مشاوره",
                        color = Color(0xFF6A0DAD),
                        fontSize = 20.sp
                    )
                }
            }
        }
    }
}

@Composable
fun KazemiFerdowsiScreen(navController: NavController) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(navController = navController, drawerState = drawerState)
        }
    ) {
        Scaffold(
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF8A2BE2),
                                    Color(0xFF4B0082))
                            )
                        )
                        .height(70.dp)
                        .padding(top = 30.dp, bottom = 10.dp, start = 16.dp, end = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = {
                        scope.launch {
                            drawerState.open()
                        }
                    }) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "منو",
                            tint = Color.White
                        )
                    }
                    Text(
                        text = "کاظمی و فردوسی",
                        textAlign = TextAlign.Right,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 20.sp,
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
            }
        }
    }
}


@Composable
fun DrawerContent(navController: NavController, drawerState: DrawerState) {
    val scope = rememberCoroutineScope()
    ModalDrawerSheet(
        modifier = Modifier
            .fillMaxHeight()
            .width(230.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFFA287DA), Color(0xFF7F51DE)
                        )
                    )
                )
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "منو",
                color = Color.White,
                fontSize = 24.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Spacer(Modifier.height(16.dp))

        DrawerItem(
            icon = Icons.Default.Home,
            text = "صفحه اصلی",
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("main_screen") {
                    popUpTo("main_screen") { inclusive = true }
                }
            }
        )
        DrawerItem(
            icon = Icons.Default.School,
            text = "دوره های من",
            onClick = { scope.launch { drawerState.close() }  }
        )
        DrawerItem(
            icon = Icons.Default.Person,
            text = "پروفایل من",
            onClick = { scope.launch { drawerState.close() }  }
        )
        DrawerItem(
            icon = Icons.Default.Email,
            text = "پیام ها",
            onClick = { scope.launch { drawerState.close() }  }
        )
        DrawerItem(
            icon = Icons.Filled.Assignment,
            text = "درخواست های ثبت شده",
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("pending_requests_screen")
            }
        )
        DrawerItem(
            icon = Icons.Default.Receipt,
            text = "تیکت ها",
            onClick = { scope.launch { drawerState.close() }  }
        )
        DrawerItem(
            icon = Icons.Default.HowToReg,
            text = "ثبت نام",
            onClick = { scope.launch { drawerState.close() }  }
        )
        DrawerItem(
            icon = Icons.Default.Group,
            text = "کاربران",
            onClick = { scope.launch { drawerState.close() } }
        )
        DrawerItem(
            icon = Icons.Default.Class,
            text = "کلاس ها",
            onClick = { scope.launch { drawerState.close() }  }
        )
        DrawerItem(
            icon = Icons.Default.Help,
            text = "راهنما",
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("consultation_registration_screen")
            }
        )

        Spacer(Modifier.weight(1f))

        DrawerItem(
            icon = Icons.Default.ExitToApp,
            text = "خروج",
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("main_screen") {
                    popUpTo(navController.graph.startDestinationId) {
                        inclusive = true
                    }
                }
            }
        )
    }
}

@Composable
fun DrawerItem(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(24.dp)
        )
        Spacer(Modifier.width(16.dp))
        Text(
            text = text,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

fun convertPersianDigitsToEnglish(input: String): String {
    val persianDigits = listOf('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹')
    val englishDigits = listOf('0','1','2','3','4','5','6','7','8','9')

    var output = input
    for (i in persianDigits.indices) {
        output = output.replace(persianDigits[i], englishDigits[i])
    }
    return output
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsultationRegistrationScreen(navController: NavController, onAddRequest : (ConsultationRequests) -> Unit) {
    var context = LocalContext.current // For confirm toast
    var name by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }

    var nameError by remember { mutableStateOf<String?>(null) }
    var lastNameError by remember { mutableStateOf<String?>(null) }
    var phoneNumberError by remember { mutableStateOf<String?>(null) }
    var topicError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }

    var expanded by remember { mutableStateOf(false) }
    val consultationTopics = listOf(
        "انتخاب نوع مشاوره",
        "مشاوره تحصیلی",
        "مشاوره ازدواج",
        "مشاوره شغلی",
        "مشاوره توانبخشی"
    )
    var selectedTopic by remember { mutableStateOf(consultationTopics[0]) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White,
                        )
                    }
                },
                title = {
                    Text(
                        text = "رزرو وقت مشاوره",
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End,
                        fontSize = 20.sp,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF6A0DAD),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.backgroundddd),
                    contentDescription = "پس زمینه",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .background(Color.White.copy(alpha = 0.8f) , RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF6A0DAD).copy(alpha = 0.8f)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "ارائه دهنده انواع مشاوره",
                            color = Color.White,
                            fontSize = 18.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }

                    // نام
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            nameError = null
                            formError = null
                        },
                        label = { Text("لطفا نام خود را وارد کنید") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = nameError != null,
                        supportingText = {
                            if (nameError != null) {
                                Text(
                                    text = nameError ?: "",
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            unfocusedLabelColor = Color.DarkGray.copy(alpha = 0.7f),
                            focusedTextColor = Color.Black.copy(alpha = 0.87f),
                            unfocusedTextColor = Color.Black.copy(alpha = 0.87f)
                        )
                    )

                    // نام خانوادگی
                    OutlinedTextField(
                        value = lastName,
                        onValueChange = {
                            lastName = it
                            lastNameError = null
                            formError = null
                        },
                        label = { Text("لطفا نام خانوادگی خود را وارد کنید") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = lastNameError != null,
                        supportingText = {
                            if (lastNameError != null) {
                                Text(
                                    text = lastNameError ?: "",
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            unfocusedLabelColor = Color.DarkGray.copy(alpha = 0.7f),
                            focusedTextColor = Color.Black.copy(alpha = 0.87f),
                            unfocusedTextColor = Color.Black.copy(alpha = 0.87f)
                        )
                    )

                    // شماره تماس
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = {
                            val filtered = it.filter { ch -> ch.isDigit() || ch in '۰'..'۹' }
                            phoneNumber = filtered
                            phoneNumberError = null
                            formError = null
                        },
                        label = { Text("لطفا شماره تماس خود را وارد کنید") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = phoneNumberError != null,
                        supportingText = {
                            if (phoneNumberError != null) {
                                Text(
                                    text = phoneNumberError ?: "",
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        },
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            unfocusedLabelColor = Color.DarkGray.copy(alpha = 0.7f),
                            focusedLabelColor = Color.Black,
                            unfocusedTextColor = Color.Black.copy(alpha = 0.87f),
                            focusedTextColor = Color.Black.copy(alpha = 0.87f)
                        )
                    )

                    // فیلد انتخاب مشاوره
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = selectedTopic,
                            onValueChange = {},
                            label = { Text("انتخاب نوع مشاوره") },
                            readOnly = true,
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                            },
                            isError = topicError != null,
                            supportingText = {
                                if (topicError != null) {
                                    Text(
                                        text = topicError ?: "",
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            colors = TextFieldDefaults.outlinedTextFieldColors(
                                unfocusedLabelColor = Color.DarkGray.copy(alpha = 0.7f),
                                focusedLabelColor = Color.Black.copy(alpha = 0.87f),
                                focusedTextColor = Color.Black.copy(alpha = 0.87f),
                                unfocusedTextColor = Color.DarkGray.copy(alpha = 0.87f)
                            )
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            consultationTopics.drop(1).forEach { topic ->
                                DropdownMenuItem(
                                    text = { Text(topic) },
                                    onClick = {
                                        selectedTopic = topic
                                        expanded = false
                                        topicError = null
                                    }
                                )
                            }
                        }
                    }

                    if (formError != null) {
                        Text(
                            text = formError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            var hasError = false

                            if (name.isBlank()) {
                                nameError = "نام نمی‌تواند خالی باشد."
                                hasError = true
                            }

                            if (lastName.isBlank()) {
                                lastNameError = "نام خانوادگی نمی‌تواند خالی باشد."
                                hasError = true
                            }

                            val phoneNumberEnglish = convertPersianDigitsToEnglish(input = phoneNumber)

                            if (phoneNumberEnglish.length != 11) {
                                phoneNumberError = "شماره تماس وارد شده صحیح نمی باشد."
                                hasError = true
                            } else if (!phoneNumberEnglish.startsWith("09")) {
                                phoneNumberError = "شماره تماس وارد شده صحیح نمی باشد."
                                hasError = true
                            }

                            if (selectedTopic == consultationTopics[0]) {
                                topicError = "لطفاً یکی از گزینه‌های مشاوره را انتخاب کنید."
                                hasError = true
                            }

                            if (!hasError) {
                                formError = null

                                val newRequest = ConsultationRequests(
                                    name = name.trim(),
                                    lastName = lastName.trim(),
                                    phoneNumber = convertPersianDigitsToEnglish(input = phoneNumber),
                                    topic = selectedTopic
                                )
                                onAddRequest(newRequest)

                                // نمایش Custom Toast به جای Toast.makeText
                                showCustomToast(
                                    context,
                                    "وقت مشاوره از طریق پیامک ارسال خواهد شد."
                                )

                                navController.navigate("main_screen") {
                                    popUpTo(navController.graph.startDestinationId) {
                                        inclusive = true
                                    }
                                }

                                name = ""
                                lastName = ""
                                phoneNumber = ""
                                selectedTopic = consultationTopics[0]
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A0DAD))
                    ) {
                        Text(
                            text = "ارسال درخواست",
                            color = Color.White,
                            fontSize = 20.sp
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PendingRequestsScreen(
    navController: NavController,
    requests : List<ConsultationRequests>
){
    Scaffold(
        topBar = {
            TopAppBar(

                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White,
                        )
                    }
                },
                title = {
                    Text(
                        text = "لیست درخواست های مشاوره",
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End,
                        fontSize = 20.sp,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF6A0DAD),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    )  {
            paddingValues ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){
        if(requests.isEmpty()){ // IF list was empty
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ){
                Text("در حال حاضر درخواستی برای نمابش وجود ندارد.")
            }
        }
        else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ){
                items(requests) {
                        request -> RequestItem(request = request)
                }
                }
            }
        }
    }
}

@Composable
fun RequestItem(request : ConsultationRequests)
{
    Card(
        modifier = Modifier
            .fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(8.dp)
    )
    {
        Column(modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        )
        {
            Text(
                text = "موضوع مشاوره : ${request.topic}",
                fontSize = 16.sp,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "شماره تماس: ${request.phoneNumber}",
                fontSize = 16.sp,
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "زمان ثبت: ${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(
                    Date(request.submissionTime)
                )}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ProzheTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            MainScreen(navController = rememberNavController())
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ConsultationRegistrationScreenPreview() {
    ProzheTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            ConsultationRegistrationScreen(
                navController = rememberNavController(),
                onAddRequest = {request -> println("")}
            )
        }
    }
}